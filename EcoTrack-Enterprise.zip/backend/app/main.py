from fastapi import FastAPI, HTTPException
from contextlib import asynccontextmanager
import pandas as pd
import joblib
import logging
import os
from app.config import settings
from app.schemas import CarbonDataInput, PredictionOutput

# 1. Setup Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("uvicorn")

# 2. Global Variables
ai_models = {
    "regressor": None,   
    "security": None     
}

# 3. Startup Logic
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 STARTUP: Loading AI Models...")

    # Load Business Model
    if os.path.exists(settings.MODEL_PATH):
        try:
            ai_models["regressor"] = joblib.load(settings.MODEL_PATH)
            logger.info(f"✅ Business Model loaded: {settings.MODEL_PATH}")
        except Exception as e:
            logger.error(f"❌ CRITICAL: Failed to load Business Model. {e}")
    else:
        logger.warning(f"⚠️  Model not found at {settings.MODEL_PATH}. RUN 'python train_models.py'!")

    # Load Security Model
    if os.path.exists(settings.SECURITY_PATH):
        try:
            ai_models["security"] = joblib.load(settings.SECURITY_PATH)
            logger.info("✅ Security Model loaded.")
        except Exception:
            logger.warning("⚠️  Could not load Security Model.")
    else:
        logger.warning("ℹ️  No Security Model found. Running in basic mode.")

    yield
    ai_models.clear()

# 4. API Definition
app = FastAPI(
    title="EcoTrack Enterprise API",
    version="4.0",
    lifespan=lifespan
)

@app.get("/health")
def health_check():
    return {
        "status": "online" if ai_models["regressor"] else "training_needed",
        "models_loaded": list(k for k,v in ai_models.items() if v)
    }

@app.post("/predict", response_model=PredictionOutput)
def predict_carbon_footprint(data: CarbonDataInput):
    if not ai_models["regressor"]:
        raise HTTPException(status_code=503, detail="Model not trained. Run 'python train_models.py' inside container.")

    try:
        # Convert Input -> DataFrame
        input_dict = data.model_dump()
        input_df = pd.DataFrame([input_dict])

        # Security Check
        is_anomaly = False
        if ai_models["security"]:
            # -1 = Anomaly, 1 = Normal
            if ai_models["security"].predict(input_df)[0] == -1:
                is_anomaly = True
                logger.warning(f"🚨 ANOMALY: {input_dict}")

        # Prediction
        prediction = ai_models["regressor"].predict(input_df)[0]

        return {
            "predicted_carbon_footprint": round(float(prediction), 2),
            "anomaly_detected": is_anomaly,
            "model_version": "v4.0_Enterprise"
        }

    except Exception as e:
        logger.error(f"Prediction Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))