import os

class Settings:
    # Based on your training logs, the app lives in /app/app inside the container
    BASE_DIR = "/app"
    
    # 1. Path to the CSV Data
    DATA_PATH = os.path.join(BASE_DIR, "data/dpp_data.csv")
    
    # 2. Path to the Trained Models (MATCHING YOUR TRAINING LOGS)
    MODEL_PATH = os.path.join(BASE_DIR, "data/model.pkl")
    SECURITY_PATH = os.path.join(BASE_DIR, "data/security_model.pkl")

settings = Settings()