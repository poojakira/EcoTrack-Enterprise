import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor, IsolationForest
import os
import sys

# Ensure we can import from app if needed, though this script is standalone
sys.path.append(os.getcwd())

# --- CONFIGURATION ---
# Paths inside the Docker container
DATA_PATH = "/app/data/dpp_data.csv"
MODEL_PATH = "/app/data/model.pkl"
SECURITY_PATH = "/app/data/security_model.pkl"

def train():
    print(f"🚀 STARTING TRAINING from {__file__}...")

    # 1. Load Data
    if not os.path.exists(DATA_PATH):
        print(f"❌ CRITICAL: Data file not found at {DATA_PATH}")
        print("   -> Please ensure 'data_dpp.csv' is in the 'backend/data' folder.")
        return

    print(f"📂 Loading dataset: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    
    # 2. Define Features (MUST match app/schemas.py)
    features = [
        "raw_material_energy", "raw_material_emission_factor", "raw_material_waste",
        "manufacturing_energy", "manufacturing_efficiency", "manufacturing_water_usage",
        "transport_distance_km", "transport_mode_factor", "logistics_energy",
        "usage_energy_consumption", "usage_duration_hours", "grid_carbon_intensity",
        "recycling_efficiency", "disposal_emission_factor", "recovered_material_value",
        "state_complexity_index", "policy_action_score", "optimization_reward_signal"
    ]
    target = "total_lifecycle_carbon_footprint"

    # Prepare Data
    X = df[features]
    y = df[target]

    # 3. Train Business Model (Regressor)
    print("🧠 Training Carbon Regressor (Random Forest)...")
    regressor = RandomForestRegressor(n_estimators=100, random_state=42)
    regressor.fit(X, y)
    
    joblib.dump(regressor, MODEL_PATH)
    print(f"✅ Saved Business Model to: {MODEL_PATH}")

    # 4. Train Security Model (Anomaly Detector)
    print("🛡️  Training Security Shield (Isolation Forest)...")
    # Contamination=0.05 means we expect 5% of data to be anomalies
    security_model = IsolationForest(contamination=0.05, random_state=42)
    security_model.fit(X)
    
    joblib.dump(security_model, SECURITY_PATH)
    print(f"✅ Saved Security Model to: {SECURITY_PATH}")

    print("🎉 TRAINING COMPLETE.")

if __name__ == "__main__":
    train()