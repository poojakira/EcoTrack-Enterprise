import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import joblib
import os
from datetime import datetime

# --- 1. ENTERPRISE CONFIGURATION ---
st.set_page_config(
    page_title="EcoTrack Enterprise Pro | Industrial Sustainability ERP",
    page_icon="🏢",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Paths as per your environment
DATA_PATH = "/app/data/dpp_data.csv" # Local fallback for the script
MODEL_PATH = "/app/data/model.pkl"
SECURITY_MODEL_PATH = "/app/data/security_model.pkl"
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")

# --- 2. ADVANCED THEMING & CSS ---
st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
    .main { background-color: #F9FAFB; }
    div[data-testid="metric-container"] {
        background-color: #FFFFFF;
        border: 1px solid #E5E7EB;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .stSidebar { background-color: #111827 !important; }
    .stSidebar * { color: #F3F4F6 !important; }
    h1, h2, h3 { color: #1F2937; font-weight: 700; }
    .stBadge { background-color: #10B981; color: white; padding: 5px 10px; border-radius: 20px; }
    </style>
    """, unsafe_allow_html=True)

# --- 3. DATA & MODEL INGESTION ---
@st.cache_resource
def load_assets():
    df = pd.read_csv(DATA_PATH)
    # Enrichment for Enterprise Visualization
    np.random.seed(42)
    categories = ['Electronics', 'Automotive', 'Aerospace', 'Medical']
    regions = ['North America', 'EMEA', 'APAC', 'LATAM']
    df['Product_ID'] = [f"SKU-{1000+i}" for i in range(len(df))]
    df['Category'] = np.random.choice(categories, len(df))
    df['Region'] = np.random.choice(regions, len(df))
    df['Timestamp'] = pd.date_range(end=datetime.now(), periods=len(df), freq='H')
    
    # Load Models
    model = joblib.load(MODEL_PATH)
    security_model = joblib.load(SECURITY_MODEL_PATH)
    
    return df, model, security_model

try:
    df, carbon_model, security_model = load_assets()
    features = list(carbon_model.feature_names_in_)
except Exception as e:
    st.error(f"Initialization Failed: {e}")
    st.stop()

# --- 4. SIDEBAR NAVIGATION & AUTHENTICATION ---
with st.sidebar:
    st.image("https://cdn-icons-png.flaticon.com/512/3135/3135715.png", width=60)
    st.title("EcoTrack v5.0")
    st.caption("Enterprise Sustainability Engine")
    
    st.divider()
    # Persona Switcher (RBAC Simulation)
    role = st.selectbox("Switch Workspace Role", 
                        ["CEO / Entrepreneur", "COO / Operations", "Logistics Manager", "Security Integrator"])
    
    st.markdown("---")
    st.success("🟢 System Secure")
    st.info(f"Connected to: {BACKEND_URL.split('//')[-1]}")

# --- 5. PERSONA-BASED DASHBOARDS ---

# =========================================================
# WORKSPACE: CEO / ENTREPRENEUR
# Focus: Revenue, ESG Compliance, Global Footprint
# =========================================================
if role == "CEO / Entrepreneur":
    st.title("🏛️ Executive Strategic Dashboard")
    
    k1, k2, k3, k4 = st.columns(4)
    total_co2 = df['total_lifecycle_carbon_footprint'].sum()
    k1.metric("Global Carbon Assets", f"{total_co2/1000:.1f}k t", "-2.4%")
    k2.metric("ESG Risk Index", "Low", "Optimized")
    k3.metric("Carbon Credit Value", f"${total_co2 * 0.08:,.0f}", "+$12k")
    k4.metric("Supply Chain Resilience", "94%", "+1.2%")

    c1, c2 = st.columns([2, 1])
    with c1:
        st.subheader("📊 Profit vs. Sustainability Correlation")
        # Simulating profit logic for entrepreneurs
        df['Simulated_Revenue'] = df['total_lifecycle_carbon_footprint'] * np.random.uniform(0.8, 1.2)
        fig = px.scatter(df, x='Simulated_Revenue', y='total_lifecycle_carbon_footprint', 
                         color='Category', size='manufacturing_efficiency', 
                         template='plotly_white', trendline="ols")
        st.plotly_chart(fig, use_container_width=True)
    
    with c2:
        st.subheader("🌍 Regional Impact")
        fig_pie = px.pie(df, names='Region', values='total_lifecycle_carbon_footprint', hole=0.5)
        st.plotly_chart(fig_pie, use_container_width=True)

# =========================================================
# WORKSPACE: COO / OPERATIONS
# Focus: Manufacturing Efficiency, Water/Energy Usage
# =========================================================
elif role == "COO / Operations":
    st.title("🏭 Operational Intelligence Hub")
    
    col1, col2, col3 = st.columns(3)
    col1.metric("Avg Mfg Efficiency", f"{df['manufacturing_efficiency'].mean()*100:.1f}%")
    col2.metric("Total Water Usage", f"{df['manufacturing_water_usage'].sum()/1000:.1f} ML")
    col3.metric("Recycling Yield", f"{df['recycling_efficiency'].mean()*100:.1f}%")

    st.subheader("⚡ Resource Consumption Heatmap")
    fig_heat = px.density_heatmap(df, x="manufacturing_efficiency", y="manufacturing_energy", 
                                 z="manufacturing_water_usage", histfunc="avg", 
                                 template="plotly_white", color_continuous_scale="Viridis")
    st.plotly_chart(fig_heat, use_container_width=True)

# =========================================================
# WORKSPACE: LOGISTICS MANAGER
# Focus: Transport, Grid Intensity, Supply Chain Nodes
# =========================================================
elif role == "Logistics Manager":
    st.title("🚚 Global Logistics & Supply Chain")
    
    m1, m2, m3 = st.columns(3)
    m1.metric("Avg Transport Dist", f"{df['transport_distance_km'].mean():.0f} km")
    m2.metric("Grid Intensity", f"{df['grid_carbon_intensity'].mean():.1f} g/kWh")
    m3.metric("Logistics Energy", f"{df['logistics_energy'].mean():.1f} kWh")

    st.subheader("📦 Delivery Carbon Intensity by Region")
    fig_box = px.box(df, x="Region", y="transport_distance_km", color="Category", template="plotly_white")
    st.plotly_chart(fig_box, use_container_width=True)

# =========================================================
# WORKSPACE: SECURITY INTEGRATOR
# Focus: Anomaly Detection, AI Security, System Logs
# =========================================================
elif role == "Security Integrator":
    st.title("🛡️ AI Security & Data Governance")
    
    # Run Security Model on existing data
    df['is_anomaly'] = security_model.predict(df[features])
    anomalies = df[df['is_anomaly'] == -1]
    
    s1, s2, s3 = st.columns(3)
    s1.metric("Security Status", "SHIELD ACTIVE", border=True)
    s2.metric("Detected Anomalies", len(anomalies), f"{len(anomalies)/len(df)*100:.2f}%")
    s3.metric("Model Integrity", "99.9%", "Validated")

    st.subheader("🚨 Real-time Anomaly Detection Feed")
    if not anomalies.empty:
        st.warning(f"System detected {len(anomalies)} data points outside of normal operating parameters.")
        st.dataframe(anomalies[['Product_ID', 'Region', 'Timestamp', 'is_anomaly']].head(10), use_container_width=True)
    else:
        st.success("No security threats detected in current data stream.")

    st.divider()
    st.subheader("🧪 AI 'What-If' Simulation (With Security Guardrails)")
    
    with st.expander("Configure Simulation Parameters"):
        input_data = {}
        cols = st.columns(3)
        for i, feat in enumerate(features):
            input_data[feat] = cols[i % 3].number_input(f"{feat}", value=float(df[feat].mean()))
    
    if st.button("🚀 Run Secure Prediction"):
        input_df = pd.DataFrame([input_data])
        
        # 1. Security Check First
        is_safe = security_model.predict(input_df)[0]
        
        if is_safe == -1:
            st.error("🛑 SECURITY ALERT: The input parameters represent a 'highly anomalous' or 'impossible' state. Prediction blocked for system integrity.")
        else:
            # 2. Prediction Second
            prediction = carbon_model.predict(input_df)[0]
            st.balloons()
            st.success(f"Prediction Authorized: Predicted Carbon Footprint is **{prediction:.2f} kg CO2**")

# --- 6. FOOTER ---
st.markdown("---")
st.markdown(f"<div style='text-align: center; color: gray;'>EcoTrack Enterprise © 2024 | Internal Data: {DATA_PATH} | Role: {role}</div>", unsafe_allow_html=True)